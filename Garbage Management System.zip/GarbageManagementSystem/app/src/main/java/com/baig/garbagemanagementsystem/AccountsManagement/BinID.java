package com.baig.garbagemanagementsystem.AccountsManagement;

public class BinID {
    public String getBinID() {
        return binID;
    }

    public void setBinID(String binID) {
        this.binID = binID;
    }

    public BinID(String binID){
        this.binID = binID;
    }


    private String binID;
}
