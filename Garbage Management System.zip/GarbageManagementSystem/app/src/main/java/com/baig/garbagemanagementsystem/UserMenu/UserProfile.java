package com.baig.garbagemanagementsystem.UserMenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.baig.garbagemanagementsystem.R;

public class UserProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);
    }
}