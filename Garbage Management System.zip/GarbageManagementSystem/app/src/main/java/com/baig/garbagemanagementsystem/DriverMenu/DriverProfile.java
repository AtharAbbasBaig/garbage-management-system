package com.baig.garbagemanagementsystem.DriverMenu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.baig.garbagemanagementsystem.R;

public class DriverProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_profile);
    }
}